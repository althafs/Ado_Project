﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;


namespace ADO_NET_PROJECT.model
{
    class DeptLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["db5"].ConnectionString;

        //GET DEPARTMENT DETAILS FUNCTION
        public DataSet getDeptDetails()
        {           

            SqlConnection conn = new SqlConnection(connStr);

            string query = "select * from Dept";
            DataSet ds = new DataSet();

            try
            {
                conn.Open();
               
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(ds);
                MessageBox.Show("Data Retrieved Successfully...");

            }
            catch(Exception)
            {
                MessageBox.Show("Failed to Connect DB..!!");
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        //INSERT DEPARTMENT DETAILS FUNCTION
        public string insertData(Dept d)
        {

            string msg = null;
            SqlConnection conn = new SqlConnection(connStr);

            string proc1 = "DEPT_INSERT";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(proc1, conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = d.DeptId;
                cmd.Parameters.Add("@DEPTNAME", SqlDbType.VarChar, 50).Value = d.DeptName;
                cmd.Parameters.Add("@DEPTLOC", SqlDbType.VarChar, 50).Value = d.DeptLoc;
                cmd.Parameters.Add("@MGR_ID", SqlDbType.Int).Value = d.MgrId;
                cmd.ExecuteNonQuery();

                msg = "Data Inserted Successfully...";

            }
            catch (Exception)
            {
                msg = "Procedure not Executed.. ";
            }

            finally
            {
                conn.Close();
            }

            return msg;
        }



        

















    }
}
